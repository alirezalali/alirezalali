import { Home, Clapperboard, Search, User, Settings } from "lucide-react";

export const navItems = [
  {
    title: "خانه",
    href: "/",
    icon: Home,
  },
  {
    title: "سریال‌ها",
    href: "/series",
    icon: Clapperboard,
  },
  {
    title: "جستجو",
    href: "/search",
    icon: Search,
  },
  {
    title: "تنظیمات",
    href: "/settings",
    icon: Settings,
  },
]; 